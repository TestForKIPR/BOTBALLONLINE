#ifndef _KIPR_BOTBALL_H_
#define _KIPR_BOTBALL_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <wallaby/wallaby.h>
#include <string.h>
#include <time.h>

#endif
