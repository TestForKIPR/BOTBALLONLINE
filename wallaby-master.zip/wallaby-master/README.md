wallaby
=======

This project provides firmware for the currently unnamed 2016 Botball Robot Controller.

It is currently under active development. 

It has been built using Crossworks... an open source build is coming soon.


Author: Joshua Southerland (2015)
