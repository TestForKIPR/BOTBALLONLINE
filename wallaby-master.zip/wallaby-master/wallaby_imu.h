#include "stm32f4xx.h"

void setupAccelMag();
void setupGyro();

void readAccel();
void readMag();
void readGyro();